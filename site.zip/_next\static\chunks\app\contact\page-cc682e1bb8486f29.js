(self.webpackChunk_N_E=self.webpackChunk_N_E||[]).push([[327],{5531:function(e,t,n){"use strict";n.d(t,{Z:function(){return a}});var r=n(2265);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=e=>e.replace(/([a-z0-9])([A-Z])/g,"$1-$2").toLowerCase(),u=(...e)=>e.filter((e,t,n)=>!!e&&n.indexOf(e)===t).join(" ");/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */var l={xmlns:"http://www.w3.org/2000/svg",width:24,height:24,viewBox:"0 0 24 24",fill:"none",stroke:"currentColor",strokeWidth:2,strokeLinecap:"round",strokeLinejoin:"round"};/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let o=(0,r.forwardRef)(({color:e="currentColor",size:t=24,strokeWidth:n=2,absoluteStrokeWidth:i,className:o="",children:a,iconNode:s,...c},f)=>(0,r.createElement)("svg",{ref:f,...l,width:t,height:t,stroke:e,strokeWidth:i?24*Number(n)/Number(t):n,className:u("lucide",o),...c},[...s.map(([e,t])=>(0,r.createElement)(e,t)),...Array.isArray(a)?a:[a]])),a=(e,t)=>{let n=(0,r.forwardRef)(({className:n,...l},a)=>(0,r.createElement)(o,{ref:a,iconNode:t,className:u(`lucide-${i(e)}`,n),...l}));return n.displayName=`${e}`,n}},2812:function(e,t,n){"use strict";n.d(t,{Z:function(){return i}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r.Z)("Building",[["rect",{width:"16",height:"20",x:"4",y:"2",rx:"2",ry:"2",key:"76otgf"}],["path",{d:"M9 22v-4h6v4",key:"r93iot"}],["path",{d:"M8 6h.01",key:"1dz90k"}],["path",{d:"M16 6h.01",key:"1x0f13"}],["path",{d:"M12 6h.01",key:"1vi96p"}],["path",{d:"M12 10h.01",key:"1nrarc"}],["path",{d:"M12 14h.01",key:"1etili"}],["path",{d:"M16 10h.01",key:"1m94wz"}],["path",{d:"M16 14h.01",key:"1gbofw"}],["path",{d:"M8 10h.01",key:"19clt8"}],["path",{d:"M8 14h.01",key:"6423bh"}]])},1295:function(e,t,n){"use strict";n.d(t,{Z:function(){return i}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r.Z)("Mail",[["rect",{width:"20",height:"16",x:"2",y:"4",rx:"2",key:"18n3k1"}],["path",{d:"m22 7-8.97 5.7a1.94 1.94 0 0 1-2.06 0L2 7",key:"1ocrg3"}]])},2882:function(e,t,n){"use strict";n.d(t,{Z:function(){return i}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r.Z)("MessageSquare",[["path",{d:"M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z",key:"1lielz"}]])},6020:function(e,t,n){"use strict";n.d(t,{Z:function(){return i}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r.Z)("Send",[["path",{d:"M14.536 21.686a.5.5 0 0 0 .937-.024l6.5-19a.496.496 0 0 0-.635-.635l-19 6.5a.5.5 0 0 0-.024.937l7.93 3.18a2 2 0 0 1 1.112 1.11z",key:"1ffxy3"}],["path",{d:"m21.854 2.147-10.94 10.939",key:"12cjpa"}]])},7972:function(e,t,n){"use strict";n.d(t,{Z:function(){return i}});var r=n(5531);/**
 * @license lucide-react v0.446.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */let i=(0,r.Z)("User",[["path",{d:"M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2",key:"975kel"}],["circle",{cx:"12",cy:"7",r:"4",key:"17ys0d"}]])},9139:function(e,t,n){Promise.resolve().then(n.bind(n,9977))},9977:function(e,t,n){"use strict";n.r(t),n.d(t,{default:function(){return l}});var r=n(7437),i=n(4251),u=n(8853);function l(){return(0,r.jsx)("div",{className:"pt-20",children:(0,r.jsx)(i.E.div,{initial:{opacity:0},animate:{opacity:1},transition:{duration:.5},children:(0,r.jsx)(u.default,{})})})}},1853:function(e,t,n){"use strict";/**
 * @license React
 * use-sync-external-store-shim.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var r=n(2265),i="function"==typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t},u=r.useState,l=r.useEffect,o=r.useLayoutEffect,a=r.useDebugValue;function s(e){var t=e.getSnapshot;e=e.value;try{var n=t();return!i(e,n)}catch(e){return!0}}var c="undefined"==typeof window||void 0===window.document||void 0===window.document.createElement?function(e,t){return t()}:function(e,t){var n=t(),r=u({inst:{value:n,getSnapshot:t}}),i=r[0].inst,c=r[1];return o(function(){i.value=n,i.getSnapshot=t,s(i)&&c({inst:i})},[e,n,t]),l(function(){return s(i)&&c({inst:i}),e(function(){s(i)&&c({inst:i})})},[e]),a(n),n};t.useSyncExternalStore=void 0!==r.useSyncExternalStore?r.useSyncExternalStore:c},8704:function(e,t,n){"use strict";/**
 * @license React
 * use-sync-external-store-shim/with-selector.production.min.js
 *
 * Copyright (c) Facebook, Inc. and its affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */var r=n(2265),i=n(6272),u="function"==typeof Object.is?Object.is:function(e,t){return e===t&&(0!==e||1/e==1/t)||e!=e&&t!=t},l=i.useSyncExternalStore,o=r.useRef,a=r.useEffect,s=r.useMemo,c=r.useDebugValue;t.useSyncExternalStoreWithSelector=function(e,t,n,r,i){var f=o(null);if(null===f.current){var d={hasValue:!1,value:null};f.current=d}else d=f.current;var h=l(e,(f=s(function(){function e(e){if(!a){if(a=!0,l=e,e=r(e),void 0!==i&&d.hasValue){var t=d.value;if(i(t,e))return o=t}return o=e}if(t=o,u(l,e))return t;var n=r(e);return void 0!==i&&i(t,n)?t:(l=e,o=n)}var l,o,a=!1,s=void 0===n?null:n;return[function(){return e(t())},null===s?void 0:function(){return e(s())}]},[t,n,r,i]))[0],f[1]);return a(function(){d.hasValue=!0,d.value=h},[h]),c(h),h}},6272:function(e,t,n){"use strict";e.exports=n(1853)},5401:function(e,t,n){"use strict";e.exports=n(8704)},2210:function(e,t,n){"use strict";n.d(t,{F:function(){return i},e:function(){return u}});var r=n(2265);function i(...e){return t=>e.forEach(e=>{"function"==typeof e?e(t):null!=e&&(e.current=t)})}function u(...e){return r.useCallback(i(...e),e)}},7256:function(e,t,n){"use strict";n.d(t,{g7:function(){return l}});var r=n(2265),i=n(2210),u=n(7437),l=r.forwardRef((e,t)=>{let{children:n,...i}=e,l=r.Children.toArray(n),a=l.find(s);if(a){let e=a.props.children,n=l.map(t=>t!==a?t:r.Children.count(e)>1?r.Children.only(null):r.isValidElement(e)?e.props.children:null);return(0,u.jsx)(o,{...i,ref:t,children:r.isValidElement(e)?r.cloneElement(e,void 0,n):null})}return(0,u.jsx)(o,{...i,ref:t,children:n})});l.displayName="Slot";var o=r.forwardRef((e,t)=>{let{children:n,...u}=e;if(r.isValidElement(n)){let e,l;let o=(e=Object.getOwnPropertyDescriptor(n.props,"ref")?.get)&&"isReactWarning"in e&&e.isReactWarning?n.ref:(e=Object.getOwnPropertyDescriptor(n,"ref")?.get)&&"isReactWarning"in e&&e.isReactWarning?n.props.ref:n.props.ref||n.ref;return r.cloneElement(n,{...function(e,t){let n={...t};for(let r in t){let i=e[r],u=t[r],l=/^on[A-Z]/.test(r);l?i&&u?n[r]=(...e)=>{u(...e),i(...e)}:i&&(n[r]=i):"style"===r?n[r]={...i,...u}:"className"===r&&(n[r]=[i,u].filter(Boolean).join(" "))}return{...e,...n}}(u,n.props),ref:t?(0,i.F)(t,o):o})}return r.Children.count(n)>1?r.Children.only(null):null});o.displayName="SlotClone";var a=({children:e})=>(0,u.jsx)(u.Fragment,{children:e});function s(e){return r.isValidElement(e)&&e.type===a}},6061:function(e,t,n){"use strict";n.d(t,{j:function(){return l}});var r=n(7042);let i=e=>"boolean"==typeof e?`${e}`:0===e?"0":e,u=r.W,l=(e,t)=>n=>{var r;if((null==t?void 0:t.variants)==null)return u(e,null==n?void 0:n.class,null==n?void 0:n.className);let{variants:l,defaultVariants:o}=t,a=Object.keys(l).map(e=>{let t=null==n?void 0:n[e],r=null==o?void 0:o[e];if(null===t)return null;let u=i(t)||i(r);return l[e][u]}),s=n&&Object.entries(n).reduce((e,t)=>{let[n,r]=t;return void 0===r||(e[n]=r),e},{}),c=null==t?void 0:null===(r=t.compoundVariants)||void 0===r?void 0:r.reduce((e,t)=>{let{class:n,className:r,...i}=t;return Object.entries(i).every(e=>{let[t,n]=e;return Array.isArray(n)?n.includes({...o,...s}[t]):({...o,...s})[t]===n})?[...e,n,r]:e},[]);return u(e,a,c,null==n?void 0:n.class,null==n?void 0:n.className)}},4660:function(e,t,n){"use strict";n.d(t,{Ue:function(){return d}});let r=e=>{let t;let n=new Set,r=(e,r)=>{let i="function"==typeof e?e(t):e;if(!Object.is(i,t)){let e=t;t=(null!=r?r:"object"!=typeof i||null===i)?i:Object.assign({},t,i),n.forEach(n=>n(t,e))}},i=()=>t,u={setState:r,getState:i,getInitialState:()=>l,subscribe:e=>(n.add(e),()=>n.delete(e)),destroy:()=>{console.warn("[DEPRECATED] The `destroy` method will be unsupported in a future version. Instead use unsubscribe function returned by subscribe. Everything will be garbage-collected if store is garbage-collected."),n.clear()}},l=t=e(r,i,u);return u},i=e=>e?r(e):r;var u=n(2265),l=n(5401);let{useDebugValue:o}=u,{useSyncExternalStoreWithSelector:a}=l,s=!1,c=e=>e,f=e=>{"function"!=typeof e&&console.warn("[DEPRECATED] Passing a vanilla store will be unsupported in a future version. Instead use `import { useStore } from 'zustand'`.");let t="function"==typeof e?i(e):e,n=(e,n)=>(function(e,t=c,n){n&&!s&&(console.warn("[DEPRECATED] Use `createWithEqualityFn` instead of `create` or use `useStoreWithEqualityFn` instead of `useStore`. They can be imported from 'zustand/traditional'. https://github.com/pmndrs/zustand/discussions/1937"),s=!0);let r=a(e.subscribe,e.getState,e.getServerState||e.getInitialState,t,n);return o(r),r})(t,e,n);return Object.assign(n,t),n},d=e=>e?f(e):f}},function(e){e.O(0,[107,853,971,864,744],function(){return e(e.s=9139)}),_N_E=e.O()}]);